-- Maren — Postgres schema
-- Postgres 16+, extensions: pgvector, postgis, pgcrypto
--
-- CONVENTIONS
--   * All ids are uuid, generated with gen_random_uuid().
--   * All timestamps are timestamptz, stored UTC.
--   * Versioned artifacts are keyed (user_id, version_hash). Nothing is ever
--     updated in place — a new version is inserted and the old row is retained.
--   * pair_key is always (lo_user_id, hi_user_id) with lo < hi lexicographically,
--     so a pair has exactly one representation.
--   * Postgres is the source of truth. Redis is a read-through cache and may be
--     flushed at any time without data loss.

CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE EXTENSION IF NOT EXISTS vector;
CREATE EXTENSION IF NOT EXISTS postgis;

-- ---------------------------------------------------------------- enums

CREATE TYPE user_status      AS ENUM ('intake','onboarding','pending_verification',
                                      'active','suppressed','banned','deleted');
CREATE TYPE tier             AS ENUM ('free','devoted');
CREATE TYPE gender           AS ENUM ('man','woman','nonbinary');
CREATE TYPE kids_status      AS ENUM ('have','dont_have','dont_want');
CREATE TYPE onboarding_phase AS ENUM ('warmup','real_talk','deep_dive','signal');
CREATE TYPE action_kind      AS ENUM ('like','dislike');
CREATE TYPE chat_status      AS ENUM ('open','removed','expired','blocked');
CREATE TYPE queue_status     AS ENUM ('waiting','opened','expired');
CREATE TYPE removal_chip     AS ENUM ('fizzled','different_direction',
                                      'no_attraction','felt_unsafe');
CREATE TYPE verification     AS ENUM ('pending','approved','rejected');

-- ---------------------------------------------------------------- users

CREATE TABLE users (
  id                    uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email                 citext,
  phone                 text,
  name                  text        NOT NULL,
  birthdate             date        NOT NULL,
  gender                gender      NOT NULL,
  interested_in         gender[]    NOT NULL,
  status                user_status NOT NULL DEFAULT 'intake',
  tier                  tier        NOT NULL DEFAULT 'free',
  -- current live artifact version. NULL until first extraction completes.
  profile_version_hash  text,
  verification_status   verification NOT NULL DEFAULT 'pending',
  verified_at           timestamptz,
  created_at            timestamptz NOT NULL DEFAULT now(),
  updated_at            timestamptz NOT NULL DEFAULT now(),
  deleted_at            timestamptz,
  CONSTRAINT users_email_or_phone CHECK (email IS NOT NULL OR phone IS NOT NULL),
  CONSTRAINT users_adult CHECK (birthdate <= (CURRENT_DATE - INTERVAL '18 years'))
);
CREATE UNIQUE INDEX users_email_uniq ON users (email) WHERE deleted_at IS NULL;
CREATE UNIQUE INDEX users_phone_uniq ON users (phone) WHERE deleted_at IS NULL;
CREATE INDEX users_active_idx ON users (status) WHERE status = 'active';

-- ---------------------------------------------------------------- profile fields
-- Collected post-Signal. Required before the first match is delivered.
-- religion and ethnicity are DISPLAY ONLY — never scored, never filtered.

CREATE TABLE profile_fields (
  user_id        uuid PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  height_cm      smallint,
  kids           kids_status,
  smoking        text,
  drinking       text,
  education      text,
  job_title      text,
  religion       text,
  ethnicity      text,
  city           text,
  location       geography(Point,4326),
  -- the only user-set preference in the product
  age_min        smallint NOT NULL DEFAULT 18,
  age_max        smallint NOT NULL DEFAULT 99,
  completed_at   timestamptz,
  updated_at     timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT age_band_sane CHECK (age_min >= 18 AND age_max >= age_min)
);
CREATE INDEX profile_fields_geo_idx ON profile_fields USING gist (location);
CREATE INDEX profile_fields_kids_idx ON profile_fields (kids);

CREATE TABLE photos (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  r2_key      text NOT NULL,
  position    smallint NOT NULL,
  moderated   boolean NOT NULL DEFAULT false,
  created_at  timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, position)
);

-- ---------------------------------------------------------------- onboarding

CREATE TABLE onboarding_sessions (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id         uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  is_revisit      boolean NOT NULL DEFAULT false,
  phase           onboarding_phase NOT NULL DEFAULT 'warmup',
  turn_count      smallint NOT NULL DEFAULT 0,
  exposure_ceiling smallint NOT NULL DEFAULT 2,
  fallback_active boolean NOT NULL DEFAULT false,
  fallback_entries smallint NOT NULL DEFAULT 0,
  -- running confidence, navigation only. Discarded once extraction returns.
  confidence      jsonb NOT NULL DEFAULT '{}'::jsonb,
  comm_profile    jsonb,
  open_hypotheses jsonb NOT NULL DEFAULT '[]'::jsonb,
  halted          boolean NOT NULL DEFAULT false,
  started_at      timestamptz NOT NULL DEFAULT now(),
  completed_at    timestamptz
);
CREATE INDEX onboarding_sessions_user_idx ON onboarding_sessions (user_id, started_at DESC);

CREATE TABLE onboarding_turns (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id     uuid NOT NULL REFERENCES onboarding_sessions(id) ON DELETE CASCADE,
  turn_number    smallint NOT NULL,
  phase          onboarding_phase NOT NULL,
  question_id    smallint,
  followup_text  text,
  anchor         smallint,
  exposure       smallint NOT NULL,
  -- purged after extraction. Encrypted at rest via pgcrypto or disk encryption.
  answer_text    text,
  maren_reply    text,
  engagement     real,
  latency_ms     integer,
  purged_at      timestamptz,
  created_at     timestamptz NOT NULL DEFAULT now(),
  UNIQUE (session_id, turn_number),
  CONSTRAINT turn_has_one_source CHECK (
    (question_id IS NOT NULL AND followup_text IS NULL) OR
    (question_id IS NULL AND followup_text IS NOT NULL) OR
    (question_id IS NULL AND followup_text IS NULL)
  )
);

-- ---------------------------------------------------------------- L2 artifacts
-- Permanent, versioned, never updated in place.

CREATE TABLE profile_versions (
  user_id        uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  version_hash   text NOT NULL,
  session_id     uuid REFERENCES onboarding_sessions(id),
  profile        jsonb NOT NULL,   -- dimensions with sub-axes
  confidence     jsonb NOT NULL,   -- per dimension, per sub-axis
  signal         jsonb NOT NULL,   -- { headline, traits[], partial }
  deeper_profile jsonb NOT NULL,   -- [{ row, text, is_gap }]
  contradictions jsonb NOT NULL DEFAULT '[]'::jsonb,
  dark_triad     jsonb NOT NULL DEFAULT '{}'::jsonb,
  flags          jsonb NOT NULL DEFAULT '{}'::jsonb,
  drift          jsonb,            -- populated on revisit extractions only
  created_at     timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (user_id, version_hash)
);

CREATE TABLE excerpts (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id       uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  version_hash  text NOT NULL,
  text          text NOT NULL,
  theme         text NOT NULL,
  -- all-MiniLM-L6-v2, written by the Python service via BullMQ
  embedding     vector(384),
  created_at    timestamptz NOT NULL DEFAULT now(),
  FOREIGN KEY (user_id, version_hash) REFERENCES profile_versions(user_id, version_hash) ON DELETE CASCADE
);
CREATE INDEX excerpts_user_idx ON excerpts (user_id, version_hash);
CREATE INDEX excerpts_vec_idx ON excerpts USING hnsw (embedding vector_cosine_ops);

CREATE TABLE user_tags (
  user_id       uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  version_hash  text NOT NULL,
  tag           text NOT NULL,
  cross_domain  boolean NOT NULL DEFAULT false,
  evidence_turns smallint[] NOT NULL DEFAULT '{}',
  superseded    boolean NOT NULL DEFAULT false,
  created_at    timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (user_id, version_hash, tag),
  FOREIGN KEY (user_id, version_hash) REFERENCES profile_versions(user_id, version_hash) ON DELETE CASCADE
);
CREATE INDEX user_tags_tag_idx ON user_tags (tag) WHERE superseded = false;

-- ---------------------------------------------------------------- L3 pair scoring

CREATE TABLE pair_scores (
  lo_user_id    uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  hi_user_id    uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  lo_version    text NOT NULL,
  hi_version    text NOT NULL,
  raw_score     real NOT NULL,
  dyadic_score  real NOT NULL,   -- APIM residual, this is what ranks
  actor_lo      real NOT NULL,
  actor_hi      real NOT NULL,
  components    jsonb NOT NULL,
  driving_dims  jsonb NOT NULL,
  evidence      jsonb NOT NULL,  -- the packet handed to the reveal prompt
  scored_at     timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (lo_user_id, hi_user_id, lo_version, hi_version),
  CONSTRAINT pair_ordered CHECK (lo_user_id < hi_user_id)
);
CREATE INDEX pair_scores_lo_idx ON pair_scores (lo_user_id, dyadic_score DESC);
CREATE INDEX pair_scores_hi_idx ON pair_scores (hi_user_id, dyadic_score DESC);

CREATE TABLE actor_means (
  user_id      uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  version_hash text NOT NULL,
  mean         real NOT NULL,
  sample_size  smallint NOT NULL,
  computed_at  timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (user_id, version_hash)
);

-- ---------------------------------------------------------------- L4 reveals
-- Permanent. Keyed to BOTH version hashes, so either user's revisit makes the
-- old row unaddressable. Nothing is ever deleted or invalidated.

CREATE TABLE reveals (
  reader_id    uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  lo_user_id   uuid NOT NULL,
  hi_user_id   uuid NOT NULL,
  lo_version   text NOT NULL,
  hi_version   text NOT NULL,
  payload      jsonb NOT NULL,
  input_tokens integer,
  output_tokens integer,
  cache_read_tokens integer,
  generated_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (reader_id, lo_user_id, hi_user_id, lo_version, hi_version)
);

-- ---------------------------------------------------------------- delivery

CREATE TABLE batches (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id       uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  candidates    uuid[] NOT NULL,
  position      smallint NOT NULL DEFAULT 0,
  size          smallint NOT NULL,
  created_at    timestamptz NOT NULL DEFAULT now(),
  exhausted_at  timestamptz
);
CREATE INDEX batches_user_open_idx ON batches (user_id) WHERE exhausted_at IS NULL;

CREATE TABLE actions (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id        uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  target_user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  kind           action_kind NOT NULL,
  batch_id       uuid REFERENCES batches(id),
  source         text NOT NULL DEFAULT 'discover',  -- discover | drawn_to_you
  created_at     timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, target_user_id)
);
CREATE INDEX actions_daily_idx ON actions (user_id, created_at DESC);
CREATE INDEX actions_incoming_idx ON actions (target_user_id, kind, created_at DESC);

-- ---------------------------------------------------------------- chat

CREATE TABLE chats (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lo_user_id      uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  hi_user_id      uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  status          chat_status NOT NULL DEFAULT 'open',
  -- clock starts when the chat actually OPENS, not when the mutual completed
  opened_at       timestamptz NOT NULL DEFAULT now(),
  last_message_at timestamptz,
  nudge_sent_at   timestamptz,
  deadline_at     timestamptz,
  closed_at       timestamptz,
  CONSTRAINT chat_ordered CHECK (lo_user_id < hi_user_id),
  UNIQUE (lo_user_id, hi_user_id)
);
CREATE INDEX chats_open_lo_idx ON chats (lo_user_id) WHERE status = 'open';
CREATE INDEX chats_open_hi_idx ON chats (hi_user_id) WHERE status = 'open';
CREATE INDEX chats_stale_idx ON chats (last_message_at) WHERE status = 'open';

CREATE TABLE messages (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  chat_id     uuid NOT NULL REFERENCES chats(id) ON DELETE CASCADE,
  sender_id   uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  body        text,
  voice_r2_key text,
  voice_expires_at timestamptz,
  created_at  timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT message_has_content CHECK (body IS NOT NULL OR voice_r2_key IS NOT NULL)
);
CREATE INDEX messages_chat_idx ON messages (chat_id, created_at DESC);

-- ---------------------------------------------------------------- hidden queue
-- Only the capped side has an entry. The other user is NOT shown a chat and is
-- NOT told a mutual exists until the entry opens.

CREATE TABLE queue_entries (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id        uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,  -- capped side
  other_user_id  uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  other_tier     tier NOT NULL,
  has_message    boolean NOT NULL DEFAULT false,
  message_body   text,          -- the single message the other side may send
  status         queue_status NOT NULL DEFAULT 'waiting',
  nudge_sent_at  timestamptz,
  queued_at      timestamptz NOT NULL DEFAULT now(),
  expires_at     timestamptz NOT NULL,
  resolved_at    timestamptz,
  resurfaced     smallint NOT NULL DEFAULT 0,
  UNIQUE (user_id, other_user_id)
);
-- resolution order: has_message DESC, other_tier DESC, queued_at ASC
CREATE INDEX queue_resolution_idx ON queue_entries
  (user_id, has_message DESC, other_tier DESC, queued_at ASC)
  WHERE status = 'waiting';
CREATE INDEX queue_expiry_idx ON queue_entries (expires_at) WHERE status = 'waiting';

-- ---------------------------------------------------------------- feedback

CREATE TABLE removals (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  chat_id     uuid NOT NULL REFERENCES chats(id) ON DELETE CASCADE,
  remover_id  uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  other_id    uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  chip        removal_chip,
  chat_days   smallint,
  message_count smallint,
  created_at  timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX removals_user_idx ON removals (remover_id, created_at DESC);

CREATE TABLE reflections (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  observation text NOT NULL,
  basis       jsonb NOT NULL,   -- the structured pattern Node detected
  shown_at    timestamptz,
  created_at  timestamptz NOT NULL DEFAULT now()
);

-- ---------------------------------------------------------------- events
-- Append only. The ONLY free validation signal for extraction accuracy.
-- Must be instrumented from launch — this data does not exist retroactively.

CREATE TABLE events (
  id          bigserial PRIMARY KEY,
  user_id     uuid REFERENCES users(id) ON DELETE SET NULL,
  type        text NOT NULL,
  payload     jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at  timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX events_user_type_idx ON events (user_id, type, created_at DESC);
CREATE INDEX events_type_idx ON events (type, created_at DESC);

-- required event types:
--   pair_shown, reveal_opened, chapter_tapped, action_taken,
--   chat_opened, first_message_sent, message_sent,
--   chat_removed, queue_entered, queue_opened, queue_expired,
--   nudge_shown, blur_shown, upgrade_started, upgrade_completed,
--   llm_call  (payload: type, model, input, output, cache_read, cache_write, ms)

-- ---------------------------------------------------------------- moderation

CREATE TABLE review_queue (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  reason      text NOT NULL,   -- dark_triad | minor_signal | describes_harming | selfie | report
  detail      jsonb NOT NULL DEFAULT '{}'::jsonb,
  resolved_by uuid REFERENCES users(id),
  resolution  text,
  created_at  timestamptz NOT NULL DEFAULT now(),
  resolved_at timestamptz
);
CREATE INDEX review_queue_open_idx ON review_queue (created_at) WHERE resolved_at IS NULL;

CREATE TABLE blocks (
  blocker_id  uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  blocked_id  uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at  timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (blocker_id, blocked_id)
);

-- ---------------------------------------------------------------- config

CREATE TABLE feature_flags (
  key         text PRIMARY KEY,
  value       jsonb NOT NULL,
  market      text NOT NULL DEFAULT 'charlotte',
  updated_by  uuid REFERENCES users(id),
  updated_at  timestamptz NOT NULL DEFAULT now()
);

-- seed values matching the decisions in the spec
INSERT INTO feature_flags (key, value) VALUES
  ('actions_free',            '{"likes":2,"dislikes":2}'),
  ('actions_devoted',         '{"likes":6,"dislikes":6}'),
  ('chat_cap_free',           '5'),
  ('soft_cap_curve',          '{"stale_days":5,"full":2,"half":5}'),
  ('batch_cap',               '15'),
  ('batch_divisor',           '25'),
  ('queue_max_depth',         '3'),
  ('queue_ttl_days',          '16'),
  ('radius_miles',            '30'),
  ('discover_free_blur',      'false'),
  ('incoming_daily_cap',      '2'),
  ('inactivity_nudge_day',    '10'),
  ('inactivity_deadline_day', '15'),
  ('voice_ttl_free_days',     '10'),
  ('voice_ttl_devoted_days',  '20');
