# Maren — Question Tagging Rubric

The rubric matters more than the tags. Tags are judgment; the rubric is what makes that judgment repeatable, auditable, and extendable to new questions.

---

## Why exposure and effort are separate

A single "depth" number conflates two independent things and breaks on the case that matters most.

**Exposure** — how much of themselves the answer reveals.
**Effort** — how much work the answer takes to produce.

Your architecture says brief users get *smaller, more structured* questions. Smaller is effort, not exposure. A terse person is not necessarily guarded — they may be entirely willing to say something raw, they just won't write three paragraphs.

Q85 proves the point: *"Is there something from a past relationship you haven't fully let go of? You don't have to tell me what."* Exposure 4. Effort 1. One word answers it completely. Under a single scale that question gets withheld from terse users, when it is the single best question to ask them.

Exposure is gated by the phase ceiling. Effort is matched to the communication profile. They never trade against each other.

---

## Exposure — 1 to 5

Rises with: present tense over past · self as subject · failure, fear or shame as content · no third party to hide behind · no socially acceptable answer available.

**1 — External and factual.** No self-judgment possible.
*"What did you do last Saturday?"*

**2 — Preference or opinion.** Socially safe, no wrong answer.
*"Morning person or night person?"*

**3 — A pattern about themselves, with a flattering reading available.**
*"Do you process things out loud or internally?"*

**4 — An admission with a cost.** Names a failure, a fear, or a pattern they would rather not have.
*"When was the last time you cried in front of someone?"*

**5 — Shame-adjacent.** No answer makes them look good, and they know it.
*"The most honest reason a relationship ended, not the version you tell people."*

## Effort — 1 to 3

Rises with: recall required · abstraction required · narrative length expected.

**1** — A word or a phrase completes it. Forced choice, or a yes/no surface that is a full answer.
**2** — A sentence or two. Needs a specific instance or a short explanation.
**3** — Narrative. Needs recall, construction, several beats.

## Escapable — true or false

The question carries a built-in out: explicit permission to withhold detail, or a yes/no surface that answers it completely.

**Escapable questions may be asked one exposure level above the current ceiling.** This is the single most useful thing in the model — it lets Maren reach depth early without risking the withdrawal that would cost her the rest of the session.

45 of 136 are escapable, including 8 at exposure 4 and 3 at exposure 5.

---

## The ratchet

Disclosure escalates reciprocally. Someone who would answer Anchor 6 comfortably at turn 10 will deflect it at turn 3 — and once they deflect, they stay guarded. So a mistimed question does not merely waste a turn, it degrades everything after it.

**Phase sets the range.** Phase 2 caps at 3. Phase 3 runs 2 to 4. Phase 4 floors at 3. The environment darkening *is* the ceiling rising, made visible.

**The ceiling only rises.** It moves up when the previous answer showed engagement — length, specificity, no deflection. It never falls.

**Anchors bypass the ceiling and set it.** They are placed by design, not chosen by gain. Anchor 3 is exposure 5 in Phase 3, and after it the ceiling is 5 for the rest of the session. The anchor spine is what drives the ratchet.

**Recovery is responsive, not scheduled.** After a maximum-exposure question the next drops two levels — one for an open user. But the beat after depth is often Maren saying something short and asking nothing at all. A lighter question asked purely to lower exposure so she can climb again is instrumental, and that is the failure mode where she stops being a friend and becomes an interviewer with good manners.

**Deflection switches format, not depth.** Two consecutive deflections do not lower the ceiling. They change the approach at the same exposure: narrative to scenario, abstract to concrete. Backing off every time someone flinches reads as not really wanting to know. Your own docs already say brief users get smaller concrete questions rather than easier ones.

---

## Distribution

| Exposure | Count | Escapable |
|---|---|---|
| 1 | 13 | 10 |
| 2 | 35 | 11 |
| 3 | 48 | 13 |
| 4 | 30 | 8 |
| 5 | 10 | 3 |

| Effort | Count |
|---|---|
| 1 | 37 |
| 2 | 64 |
| 3 | 35 |

Eligible per phase: **P2** 38 · **P3** 94 · **P4** 45.
Low-effort inventory for terse users: **P2** 16 · **P3** 24 · **P4** 8.

---

## Known thin cells

These are real and worth deciding on before launch rather than discovering at runtime.

**`values` has 2 primary-weight questions in Phase 4.** A values gap still open in Deep Dive has almost nothing eligible. Values should resolve by Phase 3, but a guarded user could finish thin with no route to fix it.

**`big_five` has 1 in Phase 4, `relationship_mindset` has 2, `eq` has 2.** Same shape, less severe.

**`emotional_regulation` and `gottman` each have 1 in Phase 2.** Fine, since neither should be probed early, but it means a Phase 2 gap on either can only be closed later.

**Phase 4 has 8 low-effort questions.** A terse user reaching Deep Dive has a narrow set. Since Phase 4 is where the excerpt bank gets its best material, this is the cell most worth widening if you add questions.

---

## Adding questions later

Tag in this order: category, then dimensions by weight, then phase eligibility, then format, then exposure, then effort, then escapable.

Exposure and effort last, and independently. If you find yourself reasoning "this feels deep so it must be long," stop — that is the conflation the two-scale model exists to prevent.
