# Maren — API Contracts

Every endpoint, socket event, webhook and job payload. Normative — the mobile client is built against this.

Read `IMPLEMENTATION.md` first. This document assumes its architecture, cache layers and business rules.

---

## 0. Conventions

**Base:** `https://api.meetmaren.app/v1`
**Auth:** `Authorization: Bearer <jwt>` on everything except `/auth/*`.
**Content type:** `application/json` throughout. Multipart only for photo upload.
**Ids:** uuid v4 as strings. Never expose internal sequence ids.
**Timestamps:** RFC 3339 UTC, always suffixed `_at`.
**Idempotency:** every mutating endpoint accepts `Idempotency-Key`. Required on actions, messages, photo upload, and the upgrade path.

**Single active session.** A new login invalidates the previous JWT. Sockets on the old token are disconnected with `session_replaced`.

**Error envelope:**

```json
{ "error": { "code": "queue_full", "message": "…", "detail": {} } }
```

`code` is a stable machine string. `message` is user-safe but the client should prefer its own copy for known codes.

| HTTP | When |
|---|---|
| 400 | validation |
| 401 | missing or invalid token |
| 403 | authenticated but not permitted — wrong tier, wrong state |
| 404 | not found, or not visible to this user |
| 409 | state conflict — already actioned, chat already open |
| 422 | business rule — out of actions, at capacity |
| 429 | rate limited, `Retry-After` set |
| 503 | dependency down, client should retry |

**422 is the interesting one.** It always carries a `reason` the client maps to a screen:

```json
{ "error": { "code": "no_actions_remaining",
             "detail": { "reason": "actions", "resets_at": "…" } } }
{ "error": { "code": "at_capacity",
             "detail": { "reason": "capacity", "chats": 5, "queued": 2 } } }
```

`reason: "actions"` → the daily blur. `reason: "capacity"` → the capacity blur, which upgrading does **not** fully resolve. Different copy. See §5.

---

## 1. Auth and intake

### `POST /auth/otp/request`
```json
{ "email": "a@b.com" }          // or { "phone": "+1…" }
→ 200 { "sent": true, "expires_at": "…" }
```
Rate limit 5/hour per identifier. Always returns 200 even for unknown identifiers — never leak account existence.

### `POST /auth/otp/verify`
```json
{ "email": "a@b.com", "code": "482913" }
→ 200 {
  "token": "eyJ…",
  "user": { "id": "…", "status": "intake", "tier": "free" },
  "next": "intake"
}
```
`next` drives client routing: `intake | onboarding | signal | profile_completion | photos | verification | active`.

### `POST /intake`
The four fields, ~30 seconds.
```json
{ "name": "Ava", "birthdate": "1997-03-14",
  "gender": "woman", "interested_in": ["man"] }
→ 201 { "user": { … }, "next": "onboarding" }
```
`birthdate` must be ≥18 years ago. 400 `underage` otherwise — never soft-fail this.

### `GET /me`
```json
→ 200 {
  "user": { "id","name","status","tier","profile_version_hash","verification_status" },
  "counts": { "chats_open": 3, "queued": 1, "actions_remaining": 2 },
  "next": "active"
}
```
Cheap. The client polls it on foreground.

---

## 2. Onboarding

### `POST /onboarding/start`
```json
{ "is_revisit": false }
→ 201 {
  "session_id": "…",
  "phase": "warmup",
  "turn": 1,
  "question": { "id": 132, "text": "What did you do last Saturday?" },
  "progress": 0.08
}
```
`progress` starts at 0.08, not 0 — endowed progress. It is a display value derived from confidence coverage, never a turn count.

A revisit requires `status: "active"` and a completed session older than the revisit gate. 403 `revisit_too_soon` with `available_at`.

### `POST /onboarding/answer`

The core loop.

```json
{ "session_id": "…", "turn": 5,
  "answer": "Honestly? I'm already writing the whole thing off…",
  "latency_ms": 34200 }
```

`latency_ms` is measured client-side from question render to send. It feeds the engagement signal — if absent the server falls back to server-side timing, which is noisier.

```json
→ 200 {
  "reply": "So you get there first.",
  "next": {
    "kind": "followup",
    "text": "Does that show up anywhere outside relationships?"
  },
  "turn": 6,
  "phase": "real_talk",
  "progress": 0.46,
  "phase_transition": null
}
```

`next.kind` is `question` (carries `id` and `text`), `followup` (text only), or `complete`.

**On transition:**
```json
"phase_transition": { "to": 4, "reason": "earned", "duration_ms": 2400 }
```
`earned` → 2400ms, full cinematic shift, Maren says nothing extra. `forced` → 1200ms, and `reply` will already contain her naming the shift. The client must not add its own line.

**On halt:**
```json
→ 200 { "reply": "…", "next": { "kind": "halt" }, "halt": true }
```
Client shows the crisis screen. No further turns accepted on this session. Server has already opened a `review_queue` row.

**Failure:** if the model call fails after retry, the server returns a deterministically selected question with a neutral reply rather than an error. A turn never 500s.

### `GET /onboarding/session/:id`
Resume after a cold start. Returns current turn, phase, and the pending question. Onboarding is resumable within 24h; after that the session is abandoned and a new one starts.

### `GET /signal`
```json
→ 200 {
  "headline": "You want closeness more than you're comfortable receiving it.",
  "traits": ["Protects fiercely","Repairs quietly","Builds to belong"],
  "partial": false,
  "constellation_seed": { "dimensions": {…}, "confidence": {…} },
  "version_hash": "v7a3f"
}
```

404 `signal_not_ready` while extraction is still queued — the client shows the waiting state and polls at 3s.

**When `partial` is true**, the client pairs the headline with the invitation line and, if `insufficient_data` is set, the plain consequence: matching is suppressed until they revisit.

`constellation_seed` is the deterministic input to the visual. Same seed, same constellation, every render — the Drawn to You miniature must match the full-screen version.

---

## 3. Profile

### `PATCH /profile/fields`
```json
{ "height_cm": 180, "kids": "dont_have", "smoking": "never",
  "city": "Charlotte", "lat": 35.22, "lng": -80.84 }
→ 200 { "complete": true, "next": "photos" }
```
Partial updates allowed. `complete` flips when every required field is present. Required: `kids`, `city`, location. The rest are optional and display-only.

**Enumerated values** — reject anything else with 400:

| Field | Values |
|---|---|
| `kids` | `have` · `dont_have` · `dont_want` |
| `smoking` | `never` · `sometimes` · `regularly` |
| `drinking` | `never` · `sometimes` · `regularly` |
| `gender` | `man` · `woman` · `nonbinary` |

**`kids` is the only field that gates matching**, and only one pairing is incompatible:

| | have | dont_have | dont_want |
|---|---|---|---|
| **have** | ✓ | ✓ | ✗ |
| **dont_have** | ✓ | ✓ | ✓ |
| **dont_want** | ✗ | ✓ | ✓ |

`dont_have` is treated as open in both directions.

`religion` and `ethnicity` are free text, accepted and displayed, **never scored, never filtered.**

### `PATCH /profile/preferences`
```json
{ "age_min": 25, "age_max": 37 }
→ 200 { "age_min": 25, "age_max": 37 }
```
The only user-set preference in the product. Default is derived server-side at intake as `age − 5` to `age + 7`, floored at 18. A client must not compute its own default.

Server enforces a hard floor beneath the user range — half-plus-7, capped at ±15 years. 400 `age_band_out_of_bounds` outside it.

### `POST /photos` — multipart
```
file: binary, ≤8MB, jpeg|png|heic
position: 0-5
→ 201 { "id": "…", "url": "…", "moderated": false }
```

### `POST /photos/reorder`
```json
{ "order": ["id1","id2","id3"] }
→ 200 { "photos": [ … ] }
```

### `POST /verification/selfie` — multipart
Returns `202` and sets `verification_status: "pending"`. Manual review. The client shows the waiting state; verification is required before the first match is delivered.

### `GET /profile/deeper`
```json
→ 200 { "rows": [
  { "row": "values", "text": "…", "is_gap": false },
  { "row": "conflict", "text": "You kept this one short. There might be more here.", "is_gap": true }
], "revisit_available_at": "2026-09-17T00:00:00Z" }
```
3–6 rows, dynamic. The client renders whatever comes back and must not assume a fixed set.

---

## 4. Discover

### `GET /discover/current`

The single most important endpoint. Returns the reveal the user is on, or the blurred card.

```json
→ 200 {
  "state": "open",
  "reveal_id": "…",
  "target": { "id":"…", "name":"Jonah", "age":31, "job":"…", "city":"Charlotte",
              "kids":"dont_have", "religion":"…", "ethnicity":"…" },
  "signal": { … },
  "photos": [ { "url":"…", "blurred": true } ],
  "chapters": {
    "why_you_two": "…",
    "echo": { "reader_words": "…", "claim": "…" },
    "hidden_layer": "…",
    "divergence_note": "…",
    "gate_variants": { "how_she_thinks":"…", "signal_alignment":"…", "what_she_protects":"…" }
  },
  "position": 3,
  "actions_remaining": 2
}
```

**Photos unblur only after the Investment Gate.** The client receives them blurred-flagged and must not pre-fetch the unblurred variant before the gate — the server serves a separate signed URL post-gate.

**Blurred states:**
```json
→ 200 {
  "state": "blurred",
  "reason": "actions",            // or "capacity"
  "target": { "id","name","age","job","city","kids" },
  "signal": { … },
  "photos": [ { "url":"…", "blurred": true } ],
  "chapters": null,
  "resets_at": "…"                // present only when reason is "actions"
}
```

`chapters` is `null` and **no LLM call fired**. The same person is returned on every request until they act — the blurred card is fixed, not rotated.

**Empty:**
```json
→ 200 { "state": "empty" }
```
Client shows the exhausted state. Identical for free and Devoted.

### `POST /discover/chapter`
```json
{ "reveal_id": "…", "chapter": "why_you_two" }
→ 204
```
Fire-and-forget telemetry, and it is the **prefetch trigger**. On `chapter: "why_you_two"` — chapter two — the server fires `prefetchReveal` for the next candidate. The client must send this or the next reveal generates on open and the user waits ~2s.

### `POST /discover/gate`
```json
{ "reveal_id": "…", "choice": "what_she_protects" }
→ 200 {
  "commentary": "…",
  "photos": [ { "url": "<signed, unblurred>", "blurred": false } ]
}
```
Returns the chosen gate variant and the unblurred photo URLs. One choice per reveal, 409 on repeat.

### `POST /discover/action`
```json
{ "reveal_id": "…", "kind": "like" }
→ 200 {
  "result": "queued",           // "chat_opened" | "queued" | "recorded"
  "chat_id": null,
  "actions_remaining": 1,
  "next_state": "open"
}
```

`result`:
- `chat_opened` — mutual, and the reader had a slot. `chat_id` is set.
- `queued` — mutual, but the **other** side is capped. From the reader's perspective this is indistinguishable from `recorded`; the client shows the same thing. The server does not disclose that a mutual occurred.
- `recorded` — no mutual yet.

**Critical:** when the reader themselves is capped, the endpoint returns 422 `at_capacity` and no action is recorded. Capacity blocks both likes and dislikes.

422 `no_actions_remaining` when the daily allowance is spent.

---

## 5. Drawn to You

### `GET /drawn`
```json
→ 200 { "cards": [
  { "id":"…", "user_id":"…",
    "signal": { … },
    "warmth": "still_warm",        // just_arrived | still_warm | cooling | fading
    "expires_at": "…" }
], "unseen": 2 }
```

No whisper field — post-MVP. Cards carry the miniaturized Signal and warmth only.

The tab indicator shows only when `cards` is non-empty. There is no empty state and the client must not render "no one liked you."

### `GET /drawn/:user_id/reveal`

Same shape as `/discover/current`, plus the disclosure chapter:

```json
"chapters": {
  "why_you_two": "…",
  "she_found_you": { "staged": ["I should tell you something.",
                                "She went through your story first. And she's already here."] },
  "echo": null,           // free tier: paywall after she_found_you
  "hidden_layer": null,
  "gate_variants": null
},
"locked": ["echo","investment_gate","hidden_layer","photo_reveal"],
"paywall": { "line": "She's waiting. And this Signal won't stay warm forever." }
```

**Devoted receives every chapter with `locked: []`.** The full payload is generated in one call regardless of tier and gated at serve time, so upgrading unlocks instantly with no second call and no wait.

---

## 6. Chat

### `GET /chats`
```json
→ 200 {
  "chats": [ { "id","other":{…},"last_message_at","status",
               "deadline_at": null, "unread": 2 } ],
  "capacity": { "open": 5, "cap": 5, "queued": 2, "has_message": 1 },
  "nudge": {
    "line": "Three people read you and chose you. Two of them wrote.",
    "sub": "I've stopped bringing you anyone new until you have room.",
    "weight": 4,
    "dismissible": false
  }
}
```

**`nudge` is server-rendered.** The client displays it verbatim and must not compose its own. It is `null` when the user is under cap. `dismissible` is always `false` — it is a state, not an interruption.

`capacity.cap` is `null` for Devoted, who receive a `delivery_slowed` nudge instead when 3+ chats are stale.

### `GET /chats/:id/messages?before=&limit=50`
Reverse chronological, cursor-paginated.

### `POST /chats/:id/messages`
```json
{ "body": "…" }                    // or { "voice_r2_key": "…", "duration_ms": 41000 }
→ 201 { "id":"…","created_at":"…" }
```
Voice max 60s. TTL set at send time from the **sender's** tier — 10 days free, 20 Devoted.

### `POST /chats/:id/remove`
```json
{ "chip": "fizzled" }
→ 200 { "slot_freed": true, "promoted": { "chat_id": "…" }, "cooldown_until": "…" }
```

`promoted` is the queue entry that filled the freed slot, resolved by `has_message DESC, other_tier DESC, queued_at ASC`. Null if the queue was empty.

`chip` is optional — max two taps, and the user may skip. `felt_unsafe` routes to `review_queue` and never enters match-quality training.

4-hour cooldown before new matches push.

### `POST /chats/:id/resolve` — the Day 15 takeover
```json
{ "choice": "let_go" }             // or "wait"
→ 200 { "status": "removed" }      // or { "status":"open", "deadline_at":"…" }
```
`wait` starts a 48-hour deadline that auto-closes with no second chance.

---

## 7. Queue

### `GET /queue`
Devoted only. Free users never see the queue as a list — only the aggregate in `/chats`.

```json
→ 200 { "entries": [
  { "id":"…","other":{…},"has_message":true,"queued_at":"…","expires_at":"…" }
] }
```

### `POST /queue/:id/open`
Devoted. Converts a queue entry into a chat. **Nothing auto-converts on upgrade** — the user opens each one.

```json
→ 200 { "chat_id": "…" }
```

### The single message

When a mutual completes and the **other** side is capped, the liker may send exactly one message, stored on the queue entry. Delivered when it opens.

```json
POST /queue/message
{ "target_user_id": "…", "body": "…" }
→ 201 { "sent": true }
→ 409 { "error": { "code": "message_already_sent" } }
```

The sender is **not** told a mutual occurred. From their side this is a one-way note. The client surfaces it as an option after a like, not as a match celebration.

---

## 8. Sockets

Namespace `/rt`, JWT in the handshake.

**Server → client**

| Event | Payload | Notes |
|---|---|---|
| `message` | `{ chat_id, message }` | |
| `chat_opened` | `{ chat_id, other }` | fires when a queue entry resolves — this is the moment the deferred match becomes real |
| `chat_closed` | `{ chat_id, reason }` | `removed \| expired \| blocked` |
| `nudge_changed` | `{ nudge }` | queue depth or message state changed |
| `queue_expired` | `{ entry_id }` | **capped side only.** Never emitted to the other user |
| `batch_ready` | `{}` | a new batch was assembled |
| `verification_result` | `{ status }` | |
| `session_replaced` | `{}` | then disconnect |

**Client → server:** `read` `{ chat_id, up_to }` only. No typing indicators — deliberately excluded to reduce relationship anxiety.

---

## 9. RevenueCat webhook

`POST /webhooks/revenuecat` — signature-verified, idempotent on `event.id`.

| Event | Effect |
|---|---|
| `INITIAL_PURCHASE`, `RENEWAL` | tier → `devoted`, soft cap immediate, grant fresh 6/6 actions regardless of what was spent today, reveal the queue, re-score the pool |
| `CANCELLATION`, `EXPIRATION` | tier → `free`. Existing chats retained; no new chats until back under 5 |
| `BILLING_ISSUE` | no tier change, flag for grace handling |

**RevenueCat is the source of truth.** The local `tier` column is a webhook-synced cache and must never be written by application code.

On upgrade the server enqueues a re-score. It re-ranks the candidate pool but does **not** reshuffle Drawn to You — the people who chose them are the people who chose them.

---

## 10. Job payloads

BullMQ. Node enqueues, Python consumes for `score` and `embed`, Node consumes the rest. **Python never writes to Redis** — results return via the queue and a Node worker persists to Postgres, then backfills Redis.

```jsonc
// queue: extraction
{ "user_id":"…", "session_id":"…", "is_revisit":false }

// queue: embed  → python
{ "user_id":"…", "version_hash":"v7a3f",
  "excerpts":[{"id":"…","text":"…"}] }
// returns: { "excerpt_id": "…", "embedding": [384 floats] }

// queue: score  → python
{ "user_id":"…", "version_hash":"…", "candidates":["uuid", …] }
// returns per pair: { lo, hi, lo_version, hi_version, raw_score,
//                     dyadic_score, actor_lo, actor_hi, components,
//                     driving_dims, evidence }

// queue: actor_mean → python
{ "user_id":"…", "version_hash":"…", "reference_sample":["uuid", …] }

// queue: queue_expiry | inactivity | reflection | voice_expiry
{ }   // cron, no payload
```

---

## 11. Rate limits

| Endpoint | Limit |
|---|---|
| `/auth/otp/request` | 5/hour per identifier |
| `/onboarding/answer` | 30/session |
| `/discover/action` | tier allowance, enforced server-side |
| `/chats/:id/messages` | 60/minute |
| `/photos` | 20/day |
| everything else | 120/minute per user |

The action allowance is **never** enforced client-side. The client reads `actions_remaining` for display only and must handle 422 regardless of what it believes.

---

## 12. Client rules

Non-negotiable, because breaking them changes product behaviour:

1. **Send `POST /discover/chapter` on chapter two.** It is the prefetch trigger. Without it the next reveal generates on open and the user waits.
2. **Never compose nudge copy.** Server-rendered, displayed verbatim.
3. **Never enforce the action cap locally.** Display only.
4. **Distinguish `reason: "actions"` from `reason: "capacity"`.** Different screens. Capacity is not resolved by upgrading — the copy must say *resolve a conversation*, not *upgrade*, or a user pays and gets nothing.
5. **The blurred card is fixed.** Same person until they act. Do not rotate, do not refresh on foreground.
6. **Never pre-fetch unblurred photos before the gate.**
7. **`deeper_profile` rows are dynamic.** 3–6, render what arrives.
8. **`age_min`/`age_max` defaults come from the server.** Never compute locally.
9. **Onboarding turns never 500.** A failed model call still returns a question. Do not build an error state for it.
10. **No typing indicators.** Not an omission.
