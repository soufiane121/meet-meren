# Maren — Backend Spec

Everything needed to build the backend. Nine files, cross-validated.

## Read in this order

1. **RECONCILIATION.md** — 20 places this spec supersedes `claude.md`. Read first,
   or you will build a 7-day queue TTL, ghost threads, 3+3 actions and a chat cap
   of 7. All wrong.
2. **IMPLEMENTATION.md** — architecture, cache layers, read paths, matching
   pipeline, jobs, build order, acceptance criteria, failure handling.
3. **schema.sql** — 22 tables, Postgres 16 + pgvector + postgis. Validated.
4. **API-CONTRACTS.md** — needed from Phase 3 onward. The mobile client is built
   against it. Phase 1 is a CLI and does not need it.

## Files

```
IMPLEMENTATION.md            the spec
API-CONTRACTS.md             every endpoint, socket event, webhook, job payload
RECONCILIATION.md            what supersedes claude.md, and why
schema.sql                   Postgres DDL, feature flags seeded
maren-tagging-rubric.md      how to tag new questions consistently

data/
  maren-question-bank.json   136 questions, weighted dimensions, phase,
                             format, exposure, effort, escapable
  maren-tag-taxonomy.json    61 tags, families, pairing polarity, evidence rules
  maren-onboarding-runtime.json  selection, ceiling, phase transitions, fallback
  maren_scoring.py           Phase 1 heuristic scorer, runnable

prompts/
  maren-prompt-system.md     all 8 prompts, 18 edge cases, validation, cache layout
```

## Conflict rule

**These files win over `claude.md` everywhere.** Do not import that file until
the reconciliation has been applied to it.

## Start here

Build order is in IMPLEMENTATION.md §10. Phase 1 is a CLI with no app, no auth,
no UI — pipeline end to end, then read the reveals it produces.

Everything in this spec assumes reveals land. Nobody has read one.

## Three things not to get wrong

**assertNoLeakage is required, not recommended.** One call sees both profiles, so
"never quote the match" is a prompt instruction. That function is what makes it a
guarantee.

**Rank on the APIM residual, never the raw score.** 82% of raw variance is actor
main effects; using it collapses every user's list onto the same profiles.

**Log `cache_read_input_tokens` on every call.** A dropped cache throws no error.
The bill just quadruples.
