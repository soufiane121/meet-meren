# Maren — Reconciliation

`claude.md` and the ML strategy doc predate this spec. They contradict it in the places below. **Apply these before importing either file, or a coding agent will build the superseded version.**

Every row was decided deliberately, with the reason recorded.

---

## Superseded

| # | Old | New | Why |
|---|---|---|---|
| 1 | Discover batch 15 fixed *(also stated as 10 elsewhere — the docs contradict themselves)* | `min(15, floor(eligible / 25))` | Simulation: batch 15 exhausts a Devoted user's eligible pool in 2.2 cycles at 300 users. Density-aware costs nothing and self-limits at launch |
| 2 | Chat cap 5 free / 7 paid | 5 free / no cap for Devoted, staleness-gated | The docs already record the 7-slot cap as replaced by the soft-cap model. Line 341 is the stale entry |
| 3 | Soft cap "thresholds TBD" | 0–2 stale chats full, 3–5 half, 6+ minimal. Stale = no message 5+ days | Counts neglect, not conversations. Twelve active chats is success; four dead ones is collecting. Uses the existing binary silence check, no new signal |
| 4 | Actions 3 likes / 3 dislikes free | 2 / 2 | Product decision |
| 5 | Radius 20 miles, user-adjustable | 30 miles, fixed | Product decision. Modelling shows radius is not the binding gate — gender/orientation and age cut ~80%, geography cuts 8% |
| 6 | Queue TTL 7–10 days, range | **16 days**, single value | At 7 days, a third of entries for a passive user expire before Day 15 enforcement can free a slot. The loss reads as arbitrary, which teaches "paywall" rather than "I should have acted" |
| 7 | Devoted sees a normal chat when the other side is capped | **No thread until it opens** | She could message into nothing for 16 days and read structural silence as rejection. Deferring the match is truthful and protects capacity better |
| 8 | Resolution: premium first, then oldest | `has_message DESC, other_tier DESC, queued_at ASC` | Effort outranks tier. A free user who wrote beats a Devoted user who did not |
| 9 | Expired pairs resurface with **regenerated** narratives | Reuse the cached reveal | If neither hash changed, the reason they fit has not changed. Free |
| 10 | Whisper on every Drawn to You card | **Post-MVP** | The only per-render LLM call. Unbounded for popular users |
| 11 | Reveals pre-generated in background jobs, "never live at browse time" | Lazy on open, prefetch one ahead | Prefetch preserves zero latency (chapters 1–2 are deterministic) and stops paying for reveals nobody opens. ~$1,900/mo → $376–684 |
| 12 | 2 AI calls per pair; gate variants generated separately | 1 call per reader per pair, all chapters and variants in one JSON | Two calls per *pair* is still correct — two readers. Four calls per *reveal* was the waste |
| 13 | ~22 AI calls per onboarding | 3 layers retained; anchors skip selection | Accuracy chosen over cost. Full verbatim history retained — the optimisation saved $70 one-time and risked quality |
| 14 | "12 psychological categories" | **13 question categories, 12 tracked dimensions** (14 keys incl. 2 enrichment) | Two different axes. Categories organise the pool; dimensions get measured |
| 15 | Love language a Phase 1 scoring input | Not used | Tier 3 demoted, no data source, no questions map to it |
| 16 | "Mood" a contextual ML feature | Removed | The daily check-in that produced it was cut from the product |
| 17 | Religion and ethnicity "used for matching only, never shown on profile" | **Display only, never scored, never filtered** | Reverses the intake copy. Ethnicity as a matching input is a discrimination exposure with no basis in the framework stack |
| 18 | Dark Triad flagging criteria "undefined" | Six red flags, already written in the question pool doc | Two or more → manual review. The criteria existed; the ML doc did not know |
| 19 | Confidence thresholds and fallback path "still need to be defined" | Defined in `data/maren-onboarding-runtime.json` | Sub-axis coverage, source-quality weighting, conflicted state, expected-gain stopping |
| 20 | Match delivery on a daily/cycle cadence | **Exhaustion-driven, no timer** | A batch arrives only when the old one is consumed and a slot is free. Makes the empty-state copy literally true |

---

## New — no equivalent exists in `claude.md`

| Artifact | What it is |
|---|---|
| `data/maren-question-bank.json` | 136 questions (110 original + 26 filling thin categories), each with weighted dimensions, phase eligibility, format, **exposure** and **effort** as separate scales, and `escapable` |
| `data/maren-tag-taxonomy.json` | 61 tags, 10 families, evidence rules, and **pairing polarity** — resonant / amplifying / neutral. Without a closed vocabulary the Hidden Layer silently returns nothing |
| `data/maren_scoring.py` | Phase 1 heuristic. Additive fit, multiplicative risk gates, differentiation as a **moderator** on attachment, APIM residual ranking |
| `data/maren-onboarding-runtime.json` | Ceiling ratchet, phase transitions earned vs forced, fallback path, shortlist contract |
| `prompts/maren-prompt-system.md` | All 8 prompts, 18 edge cases, validation rules, measured cache layout |
| `schema.sql` | 22 tables |

---

## Two findings that changed the architecture

**82% of raw pair-score variance is actor main effects.** Simulating 120 profiles, one appeared in **50 of 60** users' top-ten lists. A heuristic compatibility score inevitably becomes a ranking of who is a good partner generally — which is the popularity convergence collaborative filtering was rejected for, arriving through a different door. Ranking on the APIM residual dropped it to 11/60 and widened discrimination 4×.

**Additive weighting compressed the score into noise.** A full swing on the anxious-avoidant trap moved the final score by **0.026**, and the structure implied a fatal attachment mismatch could be compensated by shared humour. Splitting into additive fit and multiplicative risk gates restored the range: secure×secure 0.76, pursuer×withdrawer 0.41.

---

## Still open

Not blocking, but undecided.

- **Signal constellation data mapping.** Described as "asymmetric generative" and it "shifts after update," but nothing specifies which data drives the shape. If it is a seed rather than the profile, the post-Revisit shift is theatre
- **Devoted empty state.** Nothing is gated for them, so there is no blurred card — do they keep the original empty state?
- **ML cutover thresholds.** No number attached to "enough outcome data" for Phase 1 → Phase 2, and no acceptance bar for taking LambdaMART out of shadow mode. Flagged for the ML workstream
- **Intake copy.** Screen 2 still promises the opposite of decision 17 and must be rewritten before more signups see it
