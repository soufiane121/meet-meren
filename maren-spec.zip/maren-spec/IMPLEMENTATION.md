# Maren — Implementation Spec

Everything a coding agent needs to build the backend. Read this first, then the referenced files.

## Companion files — all normative

| File | Contains |
|---|---|
| `schema.sql` | Postgres DDL, 22 tables, validated |
| `data/maren-question-bank.json` | 136 questions, dimension weights, phase, format, exposure, effort, escapable |
| `data/maren-tag-taxonomy.json` | 61 tags, families, pairing polarity, evidence rules |
| `data/maren-onboarding-runtime.json` | Selection, ceiling, phase transitions, fallback, completion |
| `data/maren_scoring.py` | Reference scorer. Port or call directly |
| `prompts/maren-prompt-system.md` | All 8 prompts, edge cases, validation, cache layout |
| `API-CONTRACTS.md` | Every endpoint, socket event, webhook, job payload. Phase 3 onward |
| `RECONCILIATION.md` | Where this spec supersedes `claude.md`. Read before trusting that file |

**Conflict rule: this spec and its companions win over `claude.md` everywhere.**

---

## 1. Architecture

```
React Native (Expo)
        │  REST + Socket.io
┌───────▼─────────────────────────────┐
│  Node / TypeScript / Fastify        │
│  routes · business rules · caps     │
│  queue · throttle · cache · LLM     │
└───┬─────────────┬──────────────┬────┘
    │             │              │
┌───▼────┐   ┌────▼────┐   ┌─────▼──────┐
│Postgres│   │  Redis  │   │ Python svc │
│pgvector│   │ L1 · L4 │   │ score·embed│
│postgis │   │ locks   │   │  BullMQ    │
└────────┘   └─────────┘   └────────────┘
```

**Hard boundaries:**

- **Python never writes to Redis.** ML output goes through BullMQ → a Node worker → Postgres → Redis backfill. Postgres stays the single source of truth and two services never race on the cache.
- **The scorer is blind to business rules.** No awareness of caps, queue depth, throttle state, or tier. Node applies all of that after ranking, so a feature-flag change never triggers a rescore.
- **Only Node calls the LLM.** Python does scoring and embeddings.

**Stack:** Node 20 + TypeScript + Fastify, Postgres 16 (pgvector, postgis, pgcrypto), Redis 7 (`volatile-lru`), BullMQ, Python 3.11 + LightGBM + sentence-transformers, Socket.io, RevenueCat, Cloudflare R2, Firebase Cloud Messaging.

---

## 2. Cache layers

| | Key | Store | Lifetime |
|---|---|---|---|
| L0 | provider prompt cache | Anthropic | 5 min, refreshed on read |
| L1 | `m:accum:{userId}:{sessionId}` | Redis | session, deleted at completion |
| L2 | `m:prof\|exc\|tags:{userId}:v{hash}` | PG + Redis | permanent |
| L3 | `m:ev:{lo}_{hi}:v{hA}_v{hB}` | PG + Redis | recomputable |
| L4 | `m:rev:{reader}:{lo}_{hi}:v{hA}_v{hB}` | PG + Redis | permanent |
| — | `{key}:lock`, `{key}:fail` | Redis | 25s / 30s |
| — | `m:actor:{userId}:v{hash}` | PG + Redis | until version bump |

**Invalidation has exactly one trigger: the profile version hash.** No deletes, no cascades. When a hash changes, every key containing it stops being addressed and ages out under `volatile-lru`. There is no window in which a stale value can be served, because the stale key is not the key anyone asks for.

Pair-level keys carry **both** hashes. Either person revisiting produces a new key, which is correct.

```
version_hash = sha256(user_id || extraction_completed_at || profile_json)[:8]
```

---

## 3. Reveal read path

This is the most subtle code in the system. Implement exactly.

```ts
async function getReveal(readerId, pairKey, hA, hB) {
  const key = `m:rev:${readerId}:${pairKey}:v${hA}_v${hB}`;

  const hot = await redis.get(key);
  if (hot) return JSON.parse(hot);                       // $0

  const cold = await db.reveal.findUnique({ where: { key } });
  if (cold) {
    await redis.set(key, JSON.stringify(cold.payload), "EX", 604800);
    return cold.payload;                                 // $0
  }

  if (await redis.get(`${key}:fail`)) return degraded(pairKey, readerId);

  const lock = await redis.set(`${key}:lock`, "1", "NX", "PX", 25000);
  if (!lock) { await waitForKey(key, 25000); return getReveal(readerId, pairKey, hA, hB); }

  try {
    const evidence = await getEvidencePacket(pairKey, hA, hB);   // L3, no model
    const payload  = await generateReveal(evidence, readerId);   // the only call

    assertNoLeakage(payload, evidence.match_excerpt_texts);      // REQUIRED
    validateRevealSchema(payload);

    await db.reveal.create({ data: { key, payload } });
    await redis.set(key, JSON.stringify(payload), "EX", 604800);
    return payload;
  } catch (e) {
    await redis.set(`${key}:fail`, "1", "EX", 30);
    return degraded(pairKey, readerId);
  } finally {
    await redis.del(`${key}:lock`);
  }
}
```

**`assertNoLeakage` is not optional.** One call sees both profiles, so "never quote the match" is a prompt instruction, not a guarantee. This function is what makes it one. Compare the payload against every excerpt string in the match's bank; reject and regenerate on any verbatim hit.

**Prefetch** is `getReveal` minus the serve. Same lock, same assertion, same validation. Fires on the reader's chapter-two tap, one ahead only, never the remainder. `void prefetchReveal(...).catch(logOnly)`.

---

## 4. Onboarding turn loop

Per turn, in order:

1. `GET m:accum` → session state. Miss → rebuild from `onboarding_turns`.
2. Compute engagement in Node — length vs the user's own baseline (0.35), specificity (0.25), latency (0.15), hedging (0.15), deflection (0.10). Baseline established after turn 2. **A terse person is not disengaged, they are terse.**
3. Update exposure ceiling: rises by 1 when the **mean of the last two** answers ≥ 0.60. Never falls. A single good answer is noise.
4. Evaluate phase transition against `data/maren-onboarding-runtime.json`.
5. Build the shortlist: filter by phase, `exposure <= ceiling` (+1 if `escapable`), not in `asked[]`, effort within the comm-profile band. Rank by `tag_weight × remaining_uncertainty × demonstrated_richness`. Take 12. Send `id` and `text` only.
6. Call `onboarding_turn`. On an anchor turn send `NEXT IS FIXED` instead of a shortlist.
7. Validate. Exactly one of `next_question_id` / `followup_text` non-null; the id must be **in the shortlist**, not merely valid. Excerpt spans must appear verbatim in the answer — substring check. Drop any excerpt containing a capitalised proper noun. Reject invented tags, log, do not fail the turn.
8. Persist turn, `SET m:accum`, return reply.

**Never send the full bank.** 136 questions with tags is ~9,400 tokens; a 12-item shortlist is ~360. More importantly, sending only eligible questions makes an invalid selection structurally impossible rather than something to recover from.

---

## 5. Matching pipeline

**Absolute gates** — a Postgres query, before any scoring:

```
gender/orientation mutual  ·  age band mutual  ·  ST_DWithin 30 miles
kids compatible            ·  verified          ·  not dark-triad pending
profile complete           ·  not blocked either direction
not already actioned
```

Kids matrix — the only incompatible pairing:

| | Have | Don't have | Don't want |
|---|---|---|---|
| Have | ✓ | ✓ | ✗ |
| Don't have | ✓ | ✓ | ✓ |
| Don't want | ✗ | ✓ | ✓ |

**Religion and ethnicity are display only.** Never scored, never filtered.

**Scoring** — Python, `data/maren_scoring.py`. Additive base for fit, multiplicative gates for risk. Then rank on the **APIM residual**:

```
dyadic = raw − actor(A) − actor(B) + grand_mean
```

Ranking on the raw score converges every user's list onto the same profiles — 82% of raw variance is actor main effects. The residual fixed convergence from 53/60 to 11/60 in simulation. Actor effects still gate readiness; they do not drive the ordering.

`actor_mean` is computed against a 100–200 profile reference sample per market, refreshed weekly and on version bump.

**Batch assembly:**

```
size = min(15, floor(eligible_count / 25))
```

Self-limiting at launch — 1–2 at 300 users, 15 at 5,000 — which prevents pool exhaustion without costing anything.

**Refill is exhaustion-driven, not a timer.** A new batch arrives only when the current one is consumed **and** the user has a free chat slot. A free user at 5 chats gets **no** new batch — one fixed blurred profile stays on screen until they act.

Devoted are gated by staleness instead: 0–2 stale chats (no message 5+ days) full delivery, 3–5 half, 6+ minimal.

---

## 6. Free tier

| | |
|---|---|
| Actions | 2 likes, 2 dislikes daily |
| Chats | hard cap 5 |
| At 5 chats | no new batch; one fixed blurred profile |
| Blurred card | name, age, job, city, kids, Signal, blurred photo. **Zero LLM calls** |
| Queue | max 3, TTL 16 days, one nudge per entry |
| Drawn to You | reveal stops after "She Found You" |

**Devoted:** 6+6 actions, no chat cap, staleness-gated delivery, full Drawn to You, 20-day voice TTL. On upgrade: soft cap immediately, fresh 6/6 actions, queue becomes visible, **nothing auto-converts** — they open each one themselves.

---

## 7. Hidden queue

Entry is created only on the capped side. **The other user is not shown a chat and is not told a mutual exists.** They may send exactly one message, stored on the entry.

Do not create a placeholder thread for the uncapped side. Under the previous design a Devoted user could message into nothing for 16 days and misread structural silence as rejection.

**Resolution order — a sort tuple, not a priority number:**

```sql
ORDER BY has_message DESC, other_tier DESC, queued_at ASC
```

Effort outranks tier. A free user who wrote beats a Devoted user who did not.

**TTL is 16 days**, aligned with Day 15 enforcement. At 7 days a third of entries for a passive user expire before the mechanism that would have freed a slot has fired — the loss reads as arbitrary, and arbitrary loss teaches "this is a paywall" rather than "I should have acted."

`queued_at` is the sort key, not `matched_at` — a resurfaced entry must not inherit its original timestamp and jump the line.

---

## 8. Chat

Clock starts at `opened_at`, **not when the mutual completed**. Day 10 nudge on mutual silence, Day 15 full-screen resolution: *let go* frees the slot and collects a chip, or *wait* starts a 48-hour deadline that auto-closes with no second chance.

Devoted timers shorten as chat count rises. One-sided silence is handled differently — Maren reassures the sender and prompts the silent side.

**Server-side signals are exactly two: chat count as an integer, and a binary silence check.** No content monitoring, no typing indicators, no metadata analysis. All chat data purged on block or removal.

Removal frees the slot, collects up to two chips, then a 4-hour cooldown before new matches push. `felt_unsafe` routes to `review_queue`, never into match-quality training.

---

## 9. Jobs

| Queue | Trigger | Work |
|---|---|---|
| `extraction` | onboarding complete | Sonnet call, write L2, bump hash, enqueue embed. **Batch API — half price, nobody waiting** |
| `embed` | after extraction | Python, all-MiniLM-L6-v2 → `excerpts.embedding` |
| `score` | new version, nightly | Candidate retrieval, LightGBM, write `pair_scores` |
| `actor_mean` | version bump, weekly | Score against reference sample |
| `queue_expiry` | every 15 min | Expire past TTL, notify capped side only |
| `inactivity` | hourly | Day 10 nudge, Day 15 deadline |
| `reflection` | 4h after removal | Only when ≥3 consistent data points |
| `voice_expiry` | daily | Purge past TTL |

---

## 10. Build order

**Phase 0 — Reconcile. 1–2 days.** Apply `RECONCILIATION.md`. A coding agent reading the current `claude.md` builds a 7-day TTL, ghost threads, 3+3 actions and a chat cap of 7.

**Phase 1 — Headless pipeline. 1–2 weeks. Highest priority.**

No app, no auth, no UI. A CLI plus Postgres.

Question bank loader → deterministic selection → onboarding turn in a terminal → extraction → scoring → evidence packet → reveal generation → `assertNoLeakage` → schema validation.

Then run yourself through onboarding. Get a Signal. Do it with three friends. Pair them. **Read the reveals.**

Everything in this spec assumes reveals land, and nobody has read one. This answers that in two weeks instead of four months, and every threshold, weight and prompt gets its first real tuning here.

**Phase 2 — Persistence and cache. 1 week.** L2/L3/L4, version hashes, single-flight, negative caching. Built after call shapes are stable so you are not caching a moving target.

**Phase 3 — Vertical slice API. 2 weeks.** OTP auth, intake, onboarding endpoints, Signal, profile completion, photos.

**Phase 4 — Matching and delivery. 2 weeks.** Retrieval, gates, scoring job, batches, lazy generation with prefetch, blur.

**Phase 5 — Chat and queue. 2 weeks.** Socket.io, slots, queue, TTL, enforcement, resolution order.

**Phase 6 — Monetization. 1 week.** RevenueCat webhooks, upgrade, capacity nudge.

**From Phase 3 onward, non-negotiable:** behavioral event logging and `cache_read_input_tokens` on every LLM call. Neither exists retroactively.

---

## 11. Acceptance criteria

**Onboarding**
- 9–16 turns, ends on confidence thresholds or the 13-minute cap
- Anchors 1,2 in Warm-Up; 3,4 in Real Talk; 5,6 in Deep Dive; never repeated
- Ceiling never falls. Phase never reverses
- Open user reaches Phase 4 by turn ~7 earned; guarded user by turn 9 forced
- A forced transition sets `ceiling_did_not_rise`
- Terse user enters fallback, format switches, **exposure ceiling unchanged**
- Tier 1 below 0.60 at cap → `insufficient_data`, matching suppressed

**Extraction**
- 8–14 excerpts, ≥5 themes, all verbatim substrings of the transcript
- 3–6 `deeper_profile` rows, vocabulary keys only, ≤2 with `is_gap`
- Tags from taxonomy only; `stated_vs_revealed` requires ≥2 evidence turns
- Raw text purged, `m:accum` deleted, version hash written

**Scoring**
- Same inputs → same score, always
- Secure×secure ≈ 0.76; pursuer×withdrawer low-differentiation ≈ 0.41
- Ranking uses the dyadic residual, never the raw score
- Most-picked profile appears in <15% of users' top-10s

**Reveal**
- One call per reader per pair, ever
- `echo.reader_words` byte-matches the evidence packet
- `assertNoLeakage` passes; no dimension names, percentages or scores in any chapter
- Gate variants pairwise-distinct
- Re-entry, re-read, resurface and Drawn to You are all cache hits
- Blurred and capacity states fire **zero** calls

**Queue**
- Uncapped side sees no thread until the entry opens
- Resolution follows the sort tuple exactly
- Expiry notifies only the capped side

**Cost, 5,000 users**
- Onboarding ≈ $220 one-time
- Reveals $376–684/month
- `cache_read_input_tokens` > 0 on every call after the first

---

## 12. Failure handling

| Failure | Behaviour |
|---|---|
| Malformed LLM JSON | Validate, retry once, then deterministic fallback. Never persist unvalidated |
| Invalid question id | Deterministic selection from the shortlist. Log. Never fail the turn |
| Invented tag | Drop, log, keep the rest |
| `assertNoLeakage` fails | Regenerate once, then degraded reveal. **Never persist** |
| Reveal generation fails | 30s negative cache, serve degraded — Signal, traits, photo path |
| Redis down | Read through to Postgres. Slower, correct |
| Python service down | Serve last scored batch. Do not block delivery |
| Cache reads hit zero | Alert on the ratio. Usually whitespace, key order, or a string-vs-array system field. No error, four times the bill |
| Crisis `halt` | Stop flow, no extraction, human handler. Requires an owner |

---

## 13. Known priors

Every scoring weight, threshold, tag polarity and the 136 question tags are **reasoned, not fitted**. They are config, not code. The first real cohort will move several.

Also unvalidated: extraction accuracy has no ground truth. Behavioral signals — who initiates, response latency, whether they remove or let Day 15 do it — are the only free validation available, which is why event logging cannot be deferred.
