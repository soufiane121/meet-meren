"""
Maren Phase 1 heuristic compatibility scorer.

Structured deliberately as a LINEAR MODEL OVER ENGINEERED FEATURES so that
Phase 2 replaces the weights, not the feature pipeline. Every component is
logged per pair; when outcome labels exist, fit the weights and keep everything
else. The heuristic is the cold-start prior for the learned model, not a
throwaway.
"""
import json, math
from itertools import combinations

# ---------------------------------------------------------------- constants

# ARCHITECTURE: additive base for FIT, multiplicative gates for RISK.
# Compatibility risk is not compensable — a fatal attachment mismatch is not
# rescued by shared humour. Additive weighting says it is, and compresses the
# whole score distribution into a narrow band around the mean.

W = {                            # positive-signal components, additive
    "values_distance":   0.28,
    "mindset":           0.20,
    "tag_polarity":      0.20,
    "communication":     0.16,
    "enrichment":        0.16,
}
assert abs(sum(W.values()) - 1.0) < 1e-9

GATE = {                         # risk components, multiplicative
    "attachment_depth":  0.62,   # max proportion the attachment gate can remove
    "repair_depth":      0.40,
}

DIFFERENTIATION_MODERATION = 0.65   # how much differentiation defuses attachment risk
UNCERTAINTY_GAMMA          = 0.80   # shrinkage aggressiveness
POPULATION_MEAN            = 0.50
VALUES_TOLERANCE           = 0.20

# population baselines per component, for identifying what is DISTINCTIVE
# rather than merely unproblematic
BASELINE = {
    "values_distance": 0.86, "mindset": 0.58, "tag_polarity": 0.50,
    "communication": 0.70, "enrichment": 0.68,
    "attachment_gate": 0.80, "repair_gate": 0.82,
}

# ---------------------------------------------------------------- helpers

def clamp(x, lo=0.0, hi=1.0):
    return max(lo, min(hi, x))

def tolerant_distance(a, b, tol=VALUES_TOLERANCE):
    """Flat inside the tolerance band, then steep. Research says values
    similarity predicts at the extremes, not as a gradient."""
    d = abs(a - b)
    if d <= tol:
        return 0.0
    return ((d - tol) / (1.0 - tol)) ** 1.5


# ---------------------------------------------------------------- components

def attachment_component(A, B):
    """Two-dimensional. The pursue-withdraw trap carries the most weight
    because anxious-avoidant is the best-documented destructive pairing.

    Differentiation MODERATES rather than adds: it determines whether the
    attachment pattern runs on autopilot or gets managed. Two anxious people
    who both see their own pattern are fine. Two who don't are not.
    """
    aA, vA = A["attachment"]["anxiety"], A["attachment"]["avoidance"]
    aB, vB = B["attachment"]["anxiety"], B["attachment"]["avoidance"]

    trap     = (aA * vB + aB * vA) / 2.0      # the classic crossing
    anx_pair = aA * aB                        # both pursue, volatile
    avo_pair = vA * vB                        # both withdraw, drifts apart

    raw_risk = 0.50 * trap + 0.28 * anx_pair + 0.22 * avo_pair

    dA = A["differentiation"]["overall"]
    dB = B["differentiation"]["overall"]
    moderator = 1.0 - DIFFERENTIATION_MODERATION * ((dA + dB) / 2.0)
    risk = raw_risk * moderator

    secure_buffer = ((1 - max(aA, vA)) + (1 - max(aB, vB))) / 2.0

    risk = clamp(risk - 0.15 * secure_buffer)
    gate = 1.0 - GATE["attachment_depth"] * risk
    return gate, {"trap": round(trap,4), "anx_pair": round(anx_pair,4),
                  "avo_pair": round(avo_pair,4), "raw_risk": round(raw_risk,4),
                  "moderator": round(moderator,4),
                  "secure_buffer": round(secure_buffer,4), "net_risk": round(risk,4)}


def values_component(A, B):
    """Deal-breakers are hard filters upstream. What remains is tension
    resolution on the axes Schwartz actually separates people on."""
    axes = ["achievement_vs_connection", "security_vs_freedom", "tradition_vs_self_direction"]
    ds = [tolerant_distance(A["values"][k], B["values"][k]) for k in axes]
    score = clamp(1.0 - sum(ds) / len(ds))
    return score, {"per_axis": dict(zip(axes, ds))}


def repair_component(A, B):
    """Gottman. Repair capacity, not conflict-style similarity, is what
    predicts. A relationship's repair ability is the weaker partner's."""
    rA, rB = A["gottman"]["repair"], B["gottman"]["repair"]
    hA, hB = A["gottman"]["horsemen"], B["gottman"]["horsemen"]   # 0-1, higher = worse

    floor = min(rA, rB)
    mean  = (rA + rB) / 2.0
    horsemen_drag = (hA + hB) / 2.0

    capacity = clamp(0.65 * floor + 0.35 * mean - 0.30 * horsemen_drag)
    gate = 1.0 - GATE["repair_depth"] * (1.0 - capacity)
    return gate, {"floor": round(floor,4), "mean": round(mean,4),
                  "horsemen_drag": round(horsemen_drag,4),
                  "capacity": round(capacity,4)}


def mindset_component(A, B):
    """Destiny vs growth. Resilience is the weaker believer's, so min()
    carries real weight alongside the mean."""
    gA, gB = A["relationship_mindset"]["growth"], B["relationship_mindset"]["growth"]
    score = clamp(0.55 * min(gA, gB) + 0.45 * ((gA + gB) / 2.0))
    return score, {"min": min(gA, gB), "mean": (gA + gB) / 2.0}


def tag_polarity_component(A, B, taxonomy):
    """Uses the 57-tag taxonomy structurally. Shared resonant tags are a
    genuine finding. Shared amplifying tags compound risk. Complement pairs
    are productive difference."""
    tA, tB = set(A["tags"]), set(B["tags"])
    shared = tA & tB
    meta = {t["id"]: t for t in taxonomy["tags"]}

    resonant   = [t for t in shared if meta.get(t, {}).get("pairing") == "resonant"]
    amplifying = [t for t in shared if meta.get(t, {}).get("pairing") == "amplifying"]

    complements = []
    for t in tA:
        for c in meta.get(t, {}).get("complements", []):
            if c in tB:
                complements.append((t, c))

    raw = 0.14 * len(resonant) - 0.18 * len(amplifying) + 0.08 * len(complements)
    score = clamp(0.5 + raw)
    return score, {"shared": sorted(shared), "resonant": resonant,
                   "amplifying": amplifying, "complements": complements}


def communication_component(A, B):
    """Directness mismatch is tolerable; processing-speed mismatch is the
    one that produces the pursue-withdraw texture in daily life."""
    dd = abs(A["communication"]["directness"] - B["communication"]["directness"])
    dp = abs(A["communication"]["processing_speed"] - B["communication"]["processing_speed"])
    score = clamp(1.0 - (0.35 * dd + 0.65 * dp))
    return score, {"directness_gap": dd, "processing_gap": dp}


def enrichment_component(A, B):
    """Low predictive weight, high narrative value. This is what makes a
    reveal readable, and daily-rhythm mismatch is a real if unglamorous
    failure mode."""
    humour = 1.0 - abs(A["humor_style"] - B["humor_style"])
    texture = 1.0 - abs(A["texture"]["rhythm"] - B["texture"]["rhythm"])
    expansion = 1.0 - tolerant_distance(A["self_expansion"], B["self_expansion"], 0.30)
    score = clamp(0.35 * humour + 0.30 * texture + 0.35 * expansion)
    return score, {"humour": humour, "texture": texture, "expansion": expansion}


# ---------------------------------------------------------------- actor side

def readiness_modifier(P):
    """Actor effects are the STRONGEST predictors in the literature, and they
    are deliberately NOT used for ranking. Ranking on actor quality converges
    every user's list onto the same 'good partners' — which is precisely the
    popularity convergence collaborative filtering was rejected for.

    So actor side enters as a narrow multiplier only: it can mildly demote a
    pair where one person is clearly not ready, and it never promotes.
    """
    r = P["readiness"]          # 0-1, from expectations/differentiation
    n = P["big_five"]["N"]      # neuroticism, strongest single negative predictor
    raw = 0.60 * r + 0.40 * (1 - n)
    return 0.88 + 0.14 * raw    # bounded [0.88, 1.02]


def pair_confidence(A, B, used):
    """Geometric mean of confidence on the dimensions actually used. A thin
    profile must not rank extreme on noise."""
    vals = []
    for d in used:
        vals.append(max(0.05, A["confidence"].get(d, 0.5)))
        vals.append(max(0.05, B["confidence"].get(d, 0.5)))
    return math.exp(sum(math.log(v) for v in vals) / len(vals))


# ---------------------------------------------------------------- scorer

def score_pair(A, B, taxonomy):
    comps, detail = {}, {}
    for name, fn in [
        ("values_distance", lambda: values_component(A, B)),
        ("mindset",         lambda: mindset_component(A, B)),
        ("tag_polarity",    lambda: tag_polarity_component(A, B, taxonomy)),
        ("communication",   lambda: communication_component(A, B)),
        ("enrichment",      lambda: enrichment_component(A, B)),
    ]:
        s_, d = fn()
        comps[name], detail[name] = s_, d

    att_gate, att_detail = attachment_component(A, B)
    rep_gate, rep_detail = repair_component(A, B)
    detail["attachment_gate"] = att_detail
    detail["repair_gate"] = rep_detail
    comps["attachment_gate"] = att_gate
    comps["repair_gate"] = rep_gate

    base = sum(W[k] * comps[k] for k in W)
    gated = base * att_gate * rep_gate
    mod = readiness_modifier(A) * readiness_modifier(B)
    modded = gated * mod

    used = ["attachment", "differentiation", "values", "gottman",
            "relationship_mindset", "conflict_style"]
    conf = pair_confidence(A, B, used)
    shrunk = POPULATION_MEAN + (modded - POPULATION_MEAN) * (conf ** UNCERTAINTY_GAMMA)

    # DISTINCTIVENESS, not raw contribution. A component sitting at 1.0 because
    # nothing is wrong is not a reason two people fit — it is the absence of a
    # reason they do not. Deviation from the population baseline is what makes
    # a dimension worth telling the reader about.
    DISTINCT_DAMP = {"enrichment": 0.35}   # low predictive value, high narrative value
    dev = {}
    for k in W:
        dev[k] = W[k] * (comps[k] - BASELINE[k]) * DISTINCT_DAMP.get(k, 1.0)
    dev["attachment_gate"] = 0.9 * (att_gate - BASELINE["attachment_gate"])
    dev["repair_gate"] = 0.6 * (rep_gate - BASELINE["repair_gate"])

    driving = sorted(dev.items(), key=lambda kv: -abs(kv[1]))[:3]

    return {
        "score": round(clamp(shrunk), 4),
        "base_fit": round(base, 4),
        "attachment_gate": round(att_gate, 4),
        "repair_gate": round(rep_gate, 4),
        "readiness_mod": round(mod, 4),
        "confidence": round(conf, 4),
        "components": {k: round(v, 4) for k, v in comps.items()},
        "distinctiveness": {k: round(v, 4) for k, v in dev.items()},
        "driving_dims": [{"dim": k, "weight": round(abs(v), 4),
                          "direction": "positive" if v > 0 else "negative"}
                         for k, v in driving],
        "detail": detail,
    }


# ---------------------------------------------------------------- demo

def person(**kw):
    base = {
        "attachment": {"anxiety": 0.5, "avoidance": 0.5},
        "differentiation": {"overall": 0.5},
        "values": {"achievement_vs_connection": 0.5, "security_vs_freedom": 0.5,
                   "tradition_vs_self_direction": 0.5},
        "gottman": {"repair": 0.5, "horsemen": 0.3},
        "relationship_mindset": {"growth": 0.5},
        "communication": {"directness": 0.5, "processing_speed": 0.5},
        "humor_style": 0.5, "texture": {"rhythm": 0.5}, "self_expansion": 0.5,
        "readiness": 0.6, "big_five": {"N": 0.5},
        "tags": [], "confidence": {d: 0.8 for d in
                  ["attachment","differentiation","values","gottman",
                   "relationship_mindset","conflict_style"]},
    }
    base.update(kw)
    return base


if __name__ == "__main__":
    tax = json.load(open("/home/claude/maren-tag-taxonomy.json"))

    ava = person(
        attachment={"anxiety": 0.93, "avoidance": 0.44},
        differentiation={"overall": 0.71},
        values={"achievement_vs_connection": 0.72, "security_vs_freedom": 0.40,
                "tradition_vs_self_direction": 0.66},
        gottman={"repair": 0.74, "horsemen": 0.22},
        relationship_mindset={"growth": 0.61},
        communication={"directness": 0.70, "processing_speed": 0.45},
        readiness=0.68, big_five={"N": 0.63},
        tags=["t_preemptive_exit", "t_fast_private_repair", "t_builder_identity",
              "t_low_maintenance_front"],
    )
    jonah = person(
        attachment={"anxiety": 0.81, "avoidance": 0.39},
        differentiation={"overall": 0.66},
        values={"achievement_vs_connection": 0.63, "security_vs_freedom": 0.48,
                "tradition_vs_self_direction": 0.58},
        gottman={"repair": 0.79, "horsemen": 0.18},
        relationship_mindset={"growth": 0.70},
        communication={"directness": 0.58, "processing_speed": 0.72},
        readiness=0.72, big_five={"N": 0.58},
        tags=["t_preemptive_exit", "t_fast_private_repair", "t_own_ground",
              "t_rehearses_after"],
    )

    print("=== AVA x JONAH ===")
    r = score_pair(ava, jonah, tax)
    print(json.dumps({k: v for k, v in r.items() if k != "detail"}, indent=1))
    print("\ntag detail:", json.dumps(r["detail"]["tag_polarity"], indent=1))
    print("attachment detail:", json.dumps(r["detail"]["attachment_gate"], indent=1))

    print("\n=== SENSITIVITY: differentiation moderation ===")
    for d in (0.15, 0.40, 0.71, 0.90):
        a2 = dict(ava); a2["differentiation"] = {"overall": d}
        j2 = dict(jonah); j2["differentiation"] = {"overall": d}
        print(f"  differentiation {d:.2f} -> score {score_pair(a2, j2, tax)['score']:.4f}")

    print("\n=== SENSITIVITY: anxious-avoidant trap ===")
    for av in (0.10, 0.40, 0.70, 0.95):
        j2 = json.loads(json.dumps(jonah))
        j2["attachment"] = {"anxiety": 0.20, "avoidance": av}
        print(f"  partner avoidance {av:.2f} -> score {score_pair(ava, j2, tax)['score']:.4f}")

    print("\n=== SENSITIVITY: confidence shrinkage ===")
    for c in (0.30, 0.55, 0.80, 0.95):
        a2 = json.loads(json.dumps(ava))
        a2["confidence"] = {k: c for k in a2["confidence"]}
        print(f"  confidence {c:.2f} -> score {score_pair(a2, jonah, tax)['score']:.4f}")

    print("\n=== SECURE PAIR CONTROL ===")
    s1 = person(attachment={"anxiety": 0.18, "avoidance": 0.20},
                differentiation={"overall": 0.82}, gottman={"repair": 0.85, "horsemen": 0.10},
                relationship_mindset={"growth": 0.80}, readiness=0.80, big_five={"N": 0.28},
                tags=["t_stays_through_ambiguity", "t_names_the_thing", "t_own_ground"])
    s2 = person(attachment={"anxiety": 0.24, "avoidance": 0.16},
                differentiation={"overall": 0.78}, gottman={"repair": 0.81, "horsemen": 0.12},
                relationship_mindset={"growth": 0.76}, readiness=0.77, big_five={"N": 0.31},
                tags=["t_stays_through_ambiguity", "t_names_the_thing", "t_reconstructed_self"])
    print(f"  secure x secure -> {score_pair(s1, s2, tax)['score']:.4f}")

    print("\n=== WORST CASE: classic trap, low differentiation ===")
    p = person(attachment={"anxiety": 0.90, "avoidance": 0.15}, differentiation={"overall": 0.22},
               gottman={"repair": 0.35, "horsemen": 0.55}, readiness=0.40, big_five={"N": 0.78},
               tags=["t_reassurance_loop", "t_protest_then_withdraw"])
    w = person(attachment={"anxiety": 0.20, "avoidance": 0.88}, differentiation={"overall": 0.28},
               gottman={"repair": 0.30, "horsemen": 0.60}, readiness=0.45, big_five={"N": 0.62},
               tags=["t_holds_a_reserve", "t_room_before_reach"])
    print(f"  pursuer x withdrawer -> {score_pair(p, w, tax)['score']:.4f}")


# ---------------------------------------------------------------- APIM residual

def actor_mean(P, reference, taxonomy):
    """This person's average score against a reference sample — their ACTOR
    MAIN EFFECT. Cache per user, recompute on profile version hash change."""
    xs = [score_pair(P, R, taxonomy)["score"] for R in reference]
    return sum(xs) / len(xs)


def dyadic_score(A, B, taxonomy, actor_A, actor_B, global_mean):
    """Actor-Partner Interdependence decomposition.

        residual = score(A,B) - actor(A) - actor(B) + grand_mean

    Ranking on the raw score ranks people by general partner quality, which
    converges every user's list onto the same profiles. Ranking on the residual
    ranks on the part that is specifically about THIS pair.

    The actor effects are not discarded — they gate readiness. They just do not
    drive the ordering.
    """
    raw = score_pair(A, B, taxonomy)
    resid = raw["score"] - actor_A - actor_B + global_mean
    raw["raw_score"] = raw["score"]
    raw["actor_A"] = round(actor_A, 4)
    raw["actor_B"] = round(actor_B, 4)
    raw["dyadic_residual"] = round(resid, 4)
    raw["score"] = round(clamp(0.5 + resid * 6.0), 4)   # rescale for display
    return raw
